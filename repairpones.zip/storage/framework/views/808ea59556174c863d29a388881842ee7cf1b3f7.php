<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex">
                    <div class="col-sm-8">
                        <h2><?php echo e(__('Danh sách danh mục')); ?></h2>
                    </div>
                    <div class="col-sm-4 text-right">
                        <a href="<?php echo e(route('danh-muc.create')); ?>"><button class="btn btn-primary">Thêm mới danh mục</button></a>
                    </div>
                </div>
                <div class="card-body row justify-content-center">
                    <div class="container mt-3">
                        <div class="row">
                            <div class="col-12">
                                <table class="table table-hover table-bordered">
                                    <thead>
                                    <tr class="text-center">
                                        <th scope="col" class="">#</th>
                                        <th scope="col" class="">Title</th>
                                        <th scope="col" class="">Description</th>
                                        <th scope="col" class="">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $danhmucs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $danhmuc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="text-center">
                                        <th scope="row"><?php echo e($danhmuc->id); ?></th>
                                        <td><a href="<?php echo e(route('danh-muc.show',$danhmuc->id)); ?>"><?php echo e($danhmuc->name_cate); ?></a></td>
                                        <td><?php echo e($danhmuc->description); ?></td>
                                        <td class="d-flex align-items-center justify-content-around">
                                        <form action="<?php echo e(route('danh-muc.edit',$danhmuc->id)); ?>" method="get">
                                            <button class="btn btn-md btn-primary rounded-5">
                                            Edit
                                            </button>
                                        </form>
                                        <form action="<?php echo e(route('danh-muc.destroy',$danhmuc->id)); ?>" method="post">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <input type="hidden" name="_method" value="delete">
                                            <button class="btn btn-md btn-danger rounded-5">
                                            Delete
                                            </button>
                                        </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="d-flex justify-content-center"><?php echo e($danhmucs->links()); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>
        
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> There were some problems with your input.
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-demo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Lara/repairphone/resources/views/danhmuc/listCate.blade.php ENDPATH**/ ?>