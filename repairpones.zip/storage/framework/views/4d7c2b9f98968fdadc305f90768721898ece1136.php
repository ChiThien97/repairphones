<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><h3><?php echo e(__('Sửa danh mục')); ?></h3></div>
                <div class="card-body">
                    <form action="<?php echo e(route('danh-muc.update' , $danhmuc->id)); ?>" method="POST"  enctype="multipart/form-data">
                    <!--Tạo token để chống tấn công CSRF (Cross-site Request Forgery)-->
                    <?php echo method_field('PATCH'); ?>
                    <?php echo csrf_field(); ?> 
                        <div class="form-group row">
                            <label for="nameCate" class="col-sm-3 col-form-label">Tên danh mục</label>
                            <div class="col-sm-9">
                                <input name="nameCate" type="text" class="form-control" id="nameCate" value="<?php echo e($danhmuc->name_cate); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="description" class="col-sm-3 col-form-label">Mô tả</label>
                            <div class="col-sm-9">
                                <textarea name="description" class="form-control" id="description" ><?php echo e($danhmuc->description); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="file-image" class="col-sm-3 col-form-label">Ảnh danh mục</label>
                            <div class="col-sm-8 " id="file-image">
                                <div class="row">
                                    <a class="btn btn-sm btn-warning col-sm-3" data-toggle="collapse" data-target="#hinhanh">Sửa ảnh</a>
                                    <p class="col-sm-9"><?php echo e($danhmuc->image); ?></p>
                                </div>
                                <div id="hinhanh" style="margin-left:15px !important" class="collapse custom-file">
                                    <input name="image" type="file" class="custom-filt"  value="/images/<?php echo e($danhmuc->image); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-group row justify-content-center">
                            <div class="col-sm-3">
                                <button type="submit" class="btn btn-primary">Sửa danh mục</button>
                            </div>
                        </div>
                    </form>
                    <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong><?php echo e($message); ?></strong>
                    </div>
                    <?php if( Session::get('image') == 'Không có thay đổi hình ảnh'): ?>
                    <p><?php echo e(Session::get('image')); ?></p>
                    <?php else: ?>
                    <img src="/images/<?php echo e(Session::get('image')); ?>">
                    <?php endif; ?>
                    <?php endif; ?>
            
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> There were some problems with your input.
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Lara/repairphone/resources/views/danhmuc/editCate.blade.php ENDPATH**/ ?>