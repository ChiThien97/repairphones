<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><h3><?php echo e(__('Sửa dịch vụ')); ?></h3></div>
                <div class="card-body">
                    <form action="<?php echo e(route('dich-vu.update' , $dichvu->id)); ?>" method="POST" enctype="multipart/form-data">
                    <!--Tạo token để chống tấn công CSRF (Cross-site Request Forgery)-->
                    <?php echo method_field('PATCH'); ?>
                    <?php echo csrf_field(); ?> 
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label" for="category-list">Danh mục</label>
                            
                            <select name="idCate" style="margin-left:15px !important" class="col-sm-8 custom-select" id="category-list">
                               
                                <?php $__currentLoopData = $danhmucs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $danhmuc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($danhmuc->id == $dichvu->id_cate): ?>
                                <option value="<?php echo e($danhmuc->id); ?>" selected><?php echo e($danhmuc->name_cate); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($danhmuc->id); ?>"><?php echo e($danhmuc->name_cate); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group row">
                            <label for="nameService" class="col-sm-3 col-form-label">Tên dịch vụ</label>
                            <div class="col-sm-9">
                                <input name="nameService" type="text" class="form-control" id="nameService" value="<?php echo e($dichvu->name_service); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="price" class="col-sm-3 col-form-label">Giá niêm yết</label>
                            <div class="col-sm-9">
                                <input name="price" type="text" class="form-control" id="price" value="<?php echo e($dichvu->price); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="salePrice" class="col-sm-3 col-form-label">Giá khuyến mại</label>
                            <div class="col-sm-9">
                                <input name="salePrice" type="text" class="form-control" id="salePrice" value="<?php echo e($dichvu->sale_price); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="description" class="col-sm-3 col-form-label">Mô tả</label>
                            <div class="col-sm-9">
                                <textarea name="description" class="form-control" id="description"><?php echo e($dichvu->description); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="file-image" class="col-sm-3 col-form-label">Ảnh dịch vụ</label>
                            <div style="margin-left:15px !important" class="col-sm-8 custom-file">
                                <input name="image" type="file" class="custom-filt" id="file-image" required>
                            </div>
                        </div>
                        <div class="form-group row justify-content-center">
                            <div class="col-sm-3">
                                <button type="submit" class="btn btn-primary">Sửa dịch vụ</button>
                            </div>
                        </div>
                    </form>
                    <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block text-center">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong><?php echo e($message); ?></strong>
                            <img src="/images/<?php echo e(Session::get('image')); ?>">
                    </div>
                    
                    <?php endif; ?>
            
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> There were some problems with your input.
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Lara/repairphone/resources/views/dichvu/editService.blade.php ENDPATH**/ ?>