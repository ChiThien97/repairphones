<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><h3><?php echo e(__('Thêm danh mục mới')); ?></h3></div>
                <div class="card-body">
                    <form action="<?php echo e(route('danh-muc.store')); ?>" method="POST">
                    <!--Tạo token để chống tấn công CSRF (Cross-site Request Forgery)-->
                    <?php echo csrf_field(); ?> 
                        <div class="form-group row">
                            <label for="nameCate" class="col-sm-3 col-form-label">Tên danh mục</label>
                            <div class="col-sm-9">
                                <input name="nameCate" type="text" class="form-control" id="nameCate" placeholder="VD: Sửa chữa điện thoại ...">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="description" class="col-sm-3 col-form-label">Mô tả</label>
                            <div class="col-sm-9">
                                <textarea name="description" class="form-control" id="description" placeholder="Nhập mô tả  vào đây ..."></textarea>
                            </div>
                        </div>
                        <div class="form-group row justify-content-center">
                            <div class="col-sm-3">
                                <button type="submit" class="btn btn-primary">Thêm danh mục</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Lara/repairphones/resources/views/danhmuc/createCate.blade.php ENDPATH**/ ?>