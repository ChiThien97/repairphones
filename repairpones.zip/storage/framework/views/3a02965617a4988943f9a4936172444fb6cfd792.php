<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header d-flex">
                    <div class="col-sm-8">
                        <h2><?php echo e(__('Danh sách dịch vụ')); ?></h2>
                    </div>
                    <div class="col-sm-4 text-right">
                        <a href="<?php echo e(route('dich-vu.create')); ?>"><button class="btn btn-primary">Thêm mới dịch vụ</button></a>
                    </div>
                </div>
                <div class="card-body">
                    <?php if( isset($message) ): ?> 
                    <div class="alert alert-success" role="alert">
                        Thêm dịch vụ mới thành công !!!
                    </div>
                    <?php endif; ?>
                    <ul>
                    <?php $__currentLoopData = $dichvus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dichvu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <h3><?php echo e($dichvu->name_service); ?></h3>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php echo e($dichvus->links()); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Lara/repairphones/resources/views/dichvu/listService.blade.php ENDPATH**/ ?>