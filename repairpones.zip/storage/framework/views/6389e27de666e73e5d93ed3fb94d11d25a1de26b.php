<?php $__env->startSection('content'); ?>
<div class="container ">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card text-center">
                <div class="card-header">
                    <div>
                        <h2><?php echo e($danhmuc->name_cate); ?></h2>
                    </div>
                </div>
                <div class="card-body">
                    <div class="card">
                        <img class="card-img-top m-auto" style="width:40%" src="../images/<?php echo e($danhmuc->image); ?>" alt="<?php echo e($danhmuc->description); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($danhmuc->name_cate); ?></h5>
                            <p class="card-text"><?php echo e($danhmuc->description); ?></p>
                            <a href="<?php echo e(route('dich-vu.index')); ?>">Xem danh sách dịch vụ của danh mục <i class="fas fa-arrow-right"></i></a>
                        </div>
                    </div>
                    <div class="pull-right mt-3">
                        <a href="<?php echo e(route('danh-muc.index')); ?>" class="btn btn-success">Trở lại danh sách danh mục</a>
                        <a href="<?php echo e(route('danh-muc.edit', $danhmuc->id)); ?>" class="btn btn-primary">Sửa danh mục</a>
                        
                        <form class="mt-3" action="<?php echo e(route('danh-muc.destroy', $danhmuc->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger" type="submit">Xóa danh mục</button>
                        </form>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong><?php echo e($message); ?></strong>
                    </div>
                    <?php elseif($message = Session::get('fail')): ?>
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong><?php echo e($message); ?></strong>
                    </div>
                    <?php endif; ?>
            
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> There were some problems with your input.
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-demo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Lara/repairphone/resources/views/danhmuc/showCate.blade.php ENDPATH**/ ?>